#include "Game.h"
#include "HumanFactory.h"
#include "ChaosFactory.h"
#include "Gamefield.h"
#include "stdlibrary.h"

Game::Game(){
    this->initCurses();
    this->initWindow();
    this->field = new GameField(width, hight);
}

void Game::initWindow(){
    srand(time(0));
    //this->window = newwin(this->hight,this->width, Y_WIN, X_WIN);
   // refresh();
   // wrefresh(this->window);
}

void Game::initCurses(){

}

Game::~Game(){

}

void Game::run(){
    ChaosFactory factor;
    TMagicCharacter* unit1 = factor.createTMagicCharacter(field,5, 5);
    Unit *unit2;
    char choice = '0';
    int x = 5;
    int y = 5;

    while(choice != 'q'){
        choice = getchar();
        if (choice == 's')  { if (unit1->move(x+1,y)) x++; }
        if (choice == 'w')  { if (unit1->move(x-1,y)) x--; }
        if (choice == 'a')  { if(unit1->move(x,y-1)) y--; }
        if (choice == 'd')  { if(unit1->move(x,y+1)) y++; }
        if (choice == 'c')  { unit2 = factor.createTSiegeCharacter(field, 4,4);}
        field->update();

        for (int i = 0; i < hight; i ++) {
            for (int j = 0; j < width; j++) {
                std::cout << field->gridView[i][j];
            }
            std::cout<<"\n";
        }

    }
}
