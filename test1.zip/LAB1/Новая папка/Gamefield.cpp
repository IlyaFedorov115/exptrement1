#include "Gamefield.h"
#include "Unit.h"
#include "TerrainProxy.h"
#include "RiverProxy.h"
#include "GrassProxy.h"
#include "StoneProxy.h"
#include <cstdlib>

GameField::GameField(int width, int height)
: width_(width), height_(height), countObj(0)
{
    initialise();
    createMap();
}


void GameField::initialise()
{
    gridLogic = new pTerrain* [height_];
    gridView = new int*[height_];
    for (int i = 0; i < this->height_; i++){
        gridLogic[i] = new pTerrain[width_];
        gridView[i] = new int[width_];
        for (int j = 0; j < width_; j++){
           gridLogic[i][j] = nullptr;
           gridView[i][j] = 0;
        }
    }
}


void GameField::addObj(Obj obj){
    int cellX = obj->x_;
    int cellY = obj->y_;

    if (obj->isHero()){
        openArround(cellX, cellY);
    }
    gridLogic[cellX][cellY]->addObj(obj);

    //ну или здесь показать +
    // возможно openArround сам нарисует на отображаемой
    // сетке значения
}


void GameField::deleteObj(Obj tmp)
{
  if(tmp != nullptr) delete tmp;
}


bool GameField::move(Unit* unit, int x, int y){
    if (x < 0 || y < 0 || x >= height_ || y >= width_)
         return false;
    // Смотрим в какой клетке находимся.
    int oldCellX = unit->x_;
    int oldCellY = unit->y_;
    // Смотрим в какую клетку перемещаемся.
    int cellX = x;
    int cellY = y;

    if (!gridLogic[cellX][cellY]->isMovement())
        return false;

    //Никуда не переместились
    if (oldCellX == cellX && oldCellY == cellY)
        return false;
    unit->x_ = x;
    unit->y_ = y;

    gridLogic[oldCellX][oldCellY]->removeObj();

   // beep();
    addObj(unit);

    //Вот тут возможно стоит записать в
    // ячейку Вид-сетка, что теперь тут юнит
    return true;
}


// как??
void GameField::openArround(int x, int y)
{
  for (int curX = x-1; curX < (x+2); curX++){
    for (int curY = y-1; curY < (y+2); curY++){
      if (!(curX < 0 || curY < 0 || curX > this->width_ || curY > this->height_) && (curX != x || curY != y))
          gridLogic[curX][curY]->open();
          //gridView[curX][curY] = gridLogic[curX][curY]->show();
    }
  }
}



void GameField::update()
{
    for (int i = 0; i < height_; i ++){
        for (int j = 0; j < width_; j++) {
            gridView[i][j] = gridLogic[i][j]->getAnimation();
        }
    }
}


//Пока без параметров, одно образная карта
void GameField::createMap(){
    for (int i = 0; i < height_; i++) {
        for (int j = 0; j < width_; j++) {
           if ( ((j > 15 && j < 25)||(j > 29 && j <35) ) && (i < 13 || (i>25 && i < 36))  )
            gridLogic[i][j] = new RiverProxy(i,j);
           else if (rand()%25+1 == 7)
            gridLogic[i][j] = new StoneProxy(i,j);
           else
            gridLogic[i][j] = new GrassProxy(i,j);
        }
    }
}






GameField::~GameField(){
    for (int i = 0; i < height_; i++){
        for (int j = 0; j < width_; j++){
            if(gridLogic[i][j])
                delete gridLogic[i][j];
        }
    }
    delete [] gridLogic;
}
