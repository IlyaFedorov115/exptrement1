#include "GrassTexture.h"



GrassTexture::GrassTexture()
{
    character =  GRASS_CHARACTER;
}
