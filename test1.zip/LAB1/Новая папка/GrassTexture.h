#ifndef GRASSTEXTURE_H
#define GRASSTEXTURE_H

#include "TerrainTexture.h"


class GrassTexture : public TerrainTexture
{
 /* something else */
public:
     GrassTexture();
     virtual ~GrassTexture() {}

};

#endif // GRASSTEXTURE_H
