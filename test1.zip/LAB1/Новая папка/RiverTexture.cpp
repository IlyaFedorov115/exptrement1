#include "RiverTexture.h"


RiverTexture::RiverTexture()
{
    character = RIVER_CHARACTER;
}
