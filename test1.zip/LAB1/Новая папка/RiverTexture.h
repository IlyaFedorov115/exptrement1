#ifndef RIVERTEXTURE_H
#define RIVERTEXTURE_H

#include "TerrainTexture.h"


class RiverTexture : public TerrainTexture
{
 /* something else */
public:
     RiverTexture();
     virtual ~RiverTexture() {}

};


#endif // RIVERTEXTURE_H
