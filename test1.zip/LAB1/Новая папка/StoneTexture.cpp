#include "StoneTexture.h"



StoneTexture::StoneTexture()
{
    character =  ROCK_CHARACTER;
}

