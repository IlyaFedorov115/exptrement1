#ifndef STONETEXTURE_H
#define STONETEXTURE_H

#include "TerrainTexture.h"


class StoneTexture : public TerrainTexture
{
 /* something else */
public:
     StoneTexture();
     virtual ~StoneTexture() {}

};
#endif // STONETEXTURE_H
