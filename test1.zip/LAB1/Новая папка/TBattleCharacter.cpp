
#include "TBattleCharacter.h"

TBattleCharacter::TBattleCharacter() {

}
