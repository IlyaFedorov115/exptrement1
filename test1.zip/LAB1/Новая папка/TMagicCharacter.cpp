
#include "TMagicCharacter.h"


TMagicCharacter::TMagicCharacter(){

}
