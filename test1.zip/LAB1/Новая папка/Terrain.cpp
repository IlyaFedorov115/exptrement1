#include "Terrain.h"
#include "GameObj.h"
#include <typeinfo>
#include "TerrainTexture.h"

class Healing;


Terrain::Terrain(int x, int y)
 : cellX(x), cellY(y) {}


Obj Terrain::getObj()
{
   return obj;
}


void Terrain::removeObj(){
  if (this->obj)
  {
       setObj(nullptr);
  }
}


bool Terrain::addObj(Obj obj_)
{
   if (this->obj==nullptr){
      setObj(obj_);
      return true;
    }
 /*  if (obj_->isHero() && obj!=nullptr && obj->isNeutral())
   {
      if (typeid(*obj) == typeid(Healing)){
         Healing* ch = (Healing*)obj;
         (*obj_) += (*ch);
      }
      if (typeid(*obj) == typeid(Mine)){
         Mine* ch = (Mine*)obj;
         (*obj_) += (*ch);
      }
      setObj(obj_);
   }
   else
      return;
*/
   return false;
}


int Terrain::getAnimation(){
    if (state == OPEN)
      return texture->getTexture();
    return 0;
}



void Terrain::setObj(Obj obj_)
{
  this->obj = obj_;
  if(obj){
      if (obj->isHero())
           open();
  }
}



// ДОБАВИТЬ ОТРИСОВКУ В
// ПОЛЕ ДЛЯ ВЫВОДА

void Terrain::open()
{
    this->state = OPEN;
}


AttributeTerrain::~AttributeTerrain(){
    if (obj)
        delete obj;
    if (texture)
        delete texture;
}

Terrain::~Terrain()
{}
