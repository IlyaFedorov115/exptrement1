#include "TerrainTexture.h"


TerrainTexture::~TerrainTexture() {}


TerrainTexture::TerrainTexture(): character(0)
{}



