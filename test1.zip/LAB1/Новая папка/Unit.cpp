#include "Unit.h"
#include "Gamefield.h"



Unit::Unit()
 : hitPoint(0), armor(0), actionPoint(0), damagePoint(0)
{
      character = '?';
      state_ = NORMAL;
}


void Unit::affectBlock()
{
   state_ = BLOCK_ATTACK;
}

void Unit::updateState()
{
  state_ = NORMAL;
}


bool Unit::move(int x, int y){
    updateState();
    return field_->move(this, x, y);
}



bool Unit::isDead()
{
    return hitPoint <= 0;
}

void Unit::loseHp(int hp)
{
    hitPoint -= hp;
}

void Unit::gainHp(int hp)
{
    hitPoint += hp;
}


bool Unit::isHero()
{
    return true;
}


void Unit::update()
{
  if (isDead())
    field_->deleteObj(this);
}

