#ifndef UNIT_H
#define UNIT_H

#include "GameObj.h"



class IUnit
{
public:
    virtual bool move(int x, int y) = 0;
    //virtual bool isDead() = 0;
    //virtual void loseHp() = 0;
    //virtual void getHp() = 0;

};


class Unit : public GameObj, public IUnit
{
private:
    //friend Unit& operator+=(Unit& left, const Mine& right);
    //friend Unit& operator+=(Unit& left, const Healing& right);
    //friend Unit& operator+=(Unit& left, const Portal& right);
public:
    enum HeroState{  BLOCK_ATTACK, BLOCK_MOVEABLE, NORMAL
       /* ... */
    };
protected:
  int hitPoint;
  int armor;
  int actionPoint;
  int damagePoint;
  HeroState state_;
public:
  virtual bool move(int x, int y) override;
  virtual void update() override;                          /* Исправить потом */
  bool isDead();
  void loseHp(int hp);
  void gainHp(int hp);
  bool isHero() override;
  void affectBlock();
  void updateState() override;
  Unit();
  virtual ~Unit() {}
};

#endif // UNIT_H
