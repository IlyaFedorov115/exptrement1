#ifndef GLOBALCONST_H
#define GLOBALCONST_H

const int HUMANCLERIC_DM = 55;
const int HUMANGUARD_DM = 130;
const int HUMANTREBUCHET_DM = 60;


const int HUMANCLERIC_HP = 55;
const int HUMANGUARD_HP = 130;
const int HUMANTREBUCHET_HP = 60;
const int HUMANCLERIC_ARM = 5;
const int HUMANGUARD_ARM = 15;
const int HUMANTREBUCHET_ARM = 5;


const char HUMANCLERIC_VIEW = '@';
const char HUMANGUARD_VIEW  = '&';
const char HUMANTREBUCHET_VIEW  = '=';

const char GRETCHIN_VIEW = '&';
const char TROLSMAGIC_VIEW = '@';
const char GOBLINCATAPULT_VIEW = '=';


const int GRETCHIN_DM = 45;
const int TROLSMAGIC_DM = 70;
const int GOBLINCATAPULT_DM = 40;

const int GRETCHIN_HP = 45;
const int TROLSMAGIC_HP = 70;
const int GOBLINCATAPULT_HP = 40;
const int GRETCHIN_ARM = 0;
const int TROLSMAGIC_ARM = 5;
const int GOBLINCATAPULT_ARM = 0;
const int CATAPULT_DISTANT = 4;
const int TREBUCHET_DISTANT = 5;
const int ACTION_POINT = 60;


const int GRASS_COST = 10;
const bool GRASS_MOVEABLE = true;
const int GRASS_BACK_COLOR = 10;
const int GRASS_CHAR_COLOR = 10;
const int GRASS_CHARACTER = '.';



const int RIVER_COST = 10;
const bool RIVER_MOVEABLE = true;
const int RIVER_BACK_COLOR = 10;
const int RIVER_CHAR_COLOR = 10;
const int RIVER_CHARACTER = '~';


const int ROCK_COST = 10;
const bool ROCK_MOVEABLE = false;
const int ROCK_BACK_COLOR = 10;
const int ROCK_CHAR_COLOR = 10;
const int ROCK_CHARACTER = 'a';


#endif // GLOBALCONST_H
