#include <iostream>
#include "stdlibrary.h"
#include "Game.h"
//#include <SFML/Graphics.hpp>
#include <curses.h>

using namespace std;
//using namespace sf;


int main()
{
    initscr();
  //  RenderWindow app(VideoMode(400, 400), "Minesweeper!");
    //Game game;
    //game.run();
  /*  while (app.isOpen())
    {
        Event e;

        while (app.pollEvent(e))
        {
            if (e.type == Event::Closed)
                app.close();
        }

    } */

    return 0;
}
