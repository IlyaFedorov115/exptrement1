#ifndef STDLIBRARY_H
#define STDLIBRARY_H

#include <iostream>
#include <cstdio>
#include <unistd.h>
#include <cstdlib>
#include <cstring>
#include <ctime>
//#include <ncurses.h>



#endif // STDLIBRARY_H
